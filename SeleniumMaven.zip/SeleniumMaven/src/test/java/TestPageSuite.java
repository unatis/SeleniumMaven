import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

public class TestPageSuite {

    @Test @Order(1)
    public void TestPageTest() throws InterruptedException {

        Common.LaunchBrowser();

        Common.Navigate("http://qadocs.com/selenium.html");

        TestPage.Verify_Title_Text("Test page");

        TestPage.Verify_Paragraph_Text("Selenium automation");

        Thread.sleep(5000);

        Common.CloseBrowser();
    }

}
