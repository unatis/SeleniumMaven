import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestSuite {

    @Test @Order(1)
    public void firsttest() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "./Tools/chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get("http://www.google.com");

        WebElement element = driver.findElement(By.name("q"));

        element.sendKeys("Cheese!");

        element.submit();

        System.out.println("Page title is: " + driver.getTitle());

        Thread.sleep(5000);

        driver.quit();
    }

    @Disabled @Test @Order(2)
    public void secondtest() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "./Tools/chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get("http://www.google.com");

        WebElement element = driver.findElement(By.name("q"));

        element.sendKeys("Cheese!");

        element.submit();

        System.out.println("Page title is: " + driver.getTitle());

        Thread.sleep(5000);

        driver.quit();
    }

}
