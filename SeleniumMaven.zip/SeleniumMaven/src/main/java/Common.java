import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Common {
    public static WebDriver driver = null;

    public static void LaunchBrowser(){

        System.setProperty("webdriver.chrome.driver", "./Tools/chromedriver.exe");

        driver = new ChromeDriver();

        driver.manage().window().maximize();
    }

    public static void Navigate(String URL){

        driver.get(URL);
    }

    public static void CloseBrowser(){

        driver.quit();
    }
}
