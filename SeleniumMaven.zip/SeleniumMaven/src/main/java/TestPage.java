import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TestPage {

    public static void Verify_Title_Text(String ExpectedText){

        try{
            WebElement element = Common.driver.findElement(By.id("page_title_id"));

            String PageTitle = element.getText();

            if(PageTitle.trim().equals(ExpectedText)){
                System.out.println("Found page title: \"" + PageTitle + "\" equals to expected \"" + ExpectedText + "\"");
            }else{
                System.out.println("ERROR - Found page title: \"" + PageTitle + "\" Not equals to expected \"" + ExpectedText + "\"");
            }

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static void Verify_Paragraph_Text(String ExpectedText){

        try{
            WebElement element = Common.driver.findElement(By.name("free_text_name"));

            String ParagraphText = element.getText();

            if(ParagraphText.trim().equals(ExpectedText)){
                System.out.println("Found page Paragraph: \"" + ParagraphText + "\" equals to expected \"" + ExpectedText + "\"");
            }else{
                System.out.println("ERROR - Found page Paragraph: \"" + ParagraphText + "\" Not equals to expected \"" + ExpectedText + "\"");
            }

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
